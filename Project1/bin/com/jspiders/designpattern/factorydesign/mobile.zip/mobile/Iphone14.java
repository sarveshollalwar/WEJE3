package com.jspiders.designpattern.factorydesign.mobile;

public class Iphone14 implements Mobile {

	@Override
	public void start() {
		System.out.println("Iphone 14 is selected");
		
		
	}

}
