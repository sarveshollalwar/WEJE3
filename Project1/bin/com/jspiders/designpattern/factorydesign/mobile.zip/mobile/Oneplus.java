package com.jspiders.designpattern.factorydesign.mobile;

public class Oneplus implements Mobile {

	@Override
	public void start() {
		System.out.println("Oneplus mobile is selected");
		
	}

}
