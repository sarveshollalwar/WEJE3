package com.jspiders.designpattern.factorydesign.mobile;

public interface  Mobile {

	void start();
}
