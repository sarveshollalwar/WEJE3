package com.jspiders.designpattern.factorydesign.mobile;

public class Samsung implements Mobile {

	@Override
	public void start() {
		System.out.println("Samsung mobile is selected");
		
	}

}
