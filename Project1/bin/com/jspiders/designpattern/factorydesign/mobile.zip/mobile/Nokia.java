package com.jspiders.designpattern.factorydesign.mobile;

public class Nokia implements Mobile {

	@Override
	public void start() {
		System.out.println("Nokia mobile is selected");
		
	}

}
